def coucou():
    print("coucou")
    