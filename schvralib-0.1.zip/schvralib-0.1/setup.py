from distutils.core import setup

setup(name='schvralib',
      version='0.1',
      url='http://vra.brgm.fr'
)