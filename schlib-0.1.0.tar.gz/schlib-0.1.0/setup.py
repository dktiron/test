from setuptools import find_packages, setup

setup(name='schlib',
      packages=find_packages(include=['schlib']),
      version='0.1.0',
      author='Ben moi !',
      description='Factorisation de code hors vra',
      url='http://vra.brgm.fr')